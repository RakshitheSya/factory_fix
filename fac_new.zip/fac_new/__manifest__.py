{
    'name': 'Factory Fix',
    'version': '1.0.0',
    'summary': 'Track and manage factory maintenance operations and fixes.',
    'description': """
        Factory Fix Management Module
        =============================
        This module helps in tracking, organizing, and managing factory maintenance operations, fixes, calibration templates, and related tasks.
    """,
    'author': 'eSya',
    'website': 'http://www.esya.com',
    'license': 'LGPL-3',
    'category': 'Manufacturing',
    'depends': ['base', 'stock'],  # Ensures 'base' and 'stock' modules are loaded
    'data': [
        'security/ir.model.access.csv',  # File defining access rights for models, loaded first
        'views/factory_fix_views.xml',   # File defining the views for Factory Fix
        'views/calibration_template_views.xml',
        'views/gage_reference_view.xml',
        'views/user_defined_reference_views.xml',  # Views should be loaded after models and security
        'views/vendors_views.xml',
        'views/study_views.xml',
        'views/configure_views.xml',
        'views/libraries_views.xml',
        
],       
       
    'installable': True,
    'application': True,
    'auto_install': False,  # Set to False unless it should auto-install with dependencies
}
