from odoo import models, fields, api
from odoo.exceptions import ValidationError

class FactoryFix(models.Model):
    _name = 'factory.fix'  # Technical name of the model
    _description = 'Factory Fix Master'  # Model description

    # Fields for the Factory Fix model
    name = fields.Char(string="Name", required=True)  # Name of the fix
    gage_id = fields.Integer(string="Gage ID", required=True)  # Gage ID as numeric (integer)
    gage_number = fields.Integer(string="Gage Number")  # Gage number as numeric (integer)
    gage_type = fields.Selection([
        ('digital', 'Digital'),
        ('analog', 'Analog'),
    ], string="Gage Type", default='digital')  # Selection field for Gage Type
    gage_description = fields.Text(string="Gage Description")  # Description of the gage
    belongs_to_group = fields.Many2one('res.groups', string="Belongs to Group")  # Reference to user groups
    home_location = fields.Many2one('stock.location', string="Home Location")  # Reference to stock location
    purchased_on = fields.Date(string="Purchased On")  # Date field
    purchase_cost = fields.Float(string="Purchase Cost")  # Cost of purchase
    purchased_from = fields.Char(string="Purchased From")  # Vendor information
    service_vendor = fields.Many2one('res.partner', string="Service Vendor")  # Reference to partner (vendor)

    # New fields
    current_location = fields.Many2one('stock.location', string="Current Location")  # Current location of the gage
    owner = fields.Many2one('res.partner', string="Owner")  # Owner of the gage
    calibration_source = fields.Char(string="Calibration Source")  # Calibration source information
    current_status = fields.Selection([
        ('in_use', 'In Use'),
        ('out_of_service', 'Out of Service'),
        ('calibration_due', 'Calibration Due')
    ], string="Current Status", default='in_use')  # Current status of the gage
    gage_accuracy = fields.Float(string="Gage Accuracy")  # Accuracy of the gage
    image = fields.Binary(string="Upload Image")  # Field to upload an image
    unit_of_measure = fields.Char(string="Unit of Measure")  # Unit of measure
    gage_size = fields.Char(string="Gage Size")  # Size of the gage
    comment = fields.Text(string="Comment for Use")  # Additional comments
    
    # New checkbox fields
    is_service = fields.Boolean(string="Is Service")  # Checkbox for Is Service
    is_master = fields.Boolean(string="Is Master")  # Checkbox for Is Master

    # New numeric fields for Minimum and Maximum
    minimum = fields.Float(string="Minimum")  # Numeric field for Minimum value
    maximum = fields.Float(string="Maximum")  # Numeric field for Maximum value

    # Validation to ensure that gage_id and gage_number are positive integers
    @api.constrains('gage_id', 'gage_number')
    def _check_gage_id_and_number(self):
        for record in self:
            if record.gage_id <= 0:
                raise ValidationError("Gage ID must be a positive integer.")
            if record.gage_number and record.gage_number <= 0:
                raise ValidationError("Gage Number must be a positive integer if provided.")

    # Custom methods for Save, Delete, and Update buttons
    def action_save_record(self):
        """Save the current record."""
        self.ensure_one()  # Ensure a single record is being modified
        self.write({})  # Save the record
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': 'Success',
                'message': 'Record saved successfully!',
                'type': 'success',
                'sticky': False,
            },
        }

    def action_delete_record(self):
        """Delete the current record."""
        self.ensure_one()
        self.unlink()  # Delete the record
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': 'Deleted',
                'message': 'Record deleted successfully!',
                'type': 'danger',
                'sticky': False,
            },
        }

    def action_update_record(self):
        """Update the current record."""
        self.ensure_one()
        self.write({})  # Update the record
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': 'Updated',
                'message': 'Record updated successfully!',
                'type': 'success',
                'sticky': False,
            },
        }
