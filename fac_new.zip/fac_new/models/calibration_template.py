from odoo import models, fields, api
from odoo.exceptions import ValidationError

class CalibrationTemplate(models.Model):
    _name = 'calibration.template'
    _description = 'Calibration Template'

    sr_no = fields.Integer(string="Sr. No", required=True)
    name = fields.Char(string="Name", required=True)
    is_attribute = fields.Boolean(string="Is Attribute", default=False)
    target_value = fields.Integer(string="Target Value", required=True)
    units = fields.Char(string="Units", required=True)
    max_value = fields.Integer(string="Max. Value", required=True)
    min_value = fields.Integer(string="Min. Value", required=True)
    master = fields.Boolean(string="Master", default=False)

    @api.constrains('name', 'units')
    def _check_character_fields(self):
        for record in self:
            if not record.name.isalpha():
                raise ValidationError("The 'Name' field should contain only characters.")
            if not record.units.isalpha():
                raise ValidationError("The 'Units' field should contain only characters.")

    @api.constrains('target_value', 'max_value', 'min_value')
    def _check_numeric_fields(self):
        for record in self:
            if not isinstance(record.target_value, int):
                raise ValidationError("The 'Target Value' must be an integer.")
            if not isinstance(record.max_value, int):
                raise ValidationError("The 'Max. Value' must be an integer.")
            if not isinstance(record.min_value, int):
                raise ValidationError("The 'Min. Value' must be an integer.")
