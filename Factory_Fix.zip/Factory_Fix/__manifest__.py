{
    'name': 'Factory Fix',
    'version': '1.0.0',
    'summary': 'Track and manage factory maintenance operations and fixes.',
    'description': """
        Factory Fix Management Module
        =============================
        This module helps in tracking, organizing, and managing factory maintenance operations, 
        fixes, calibration templates, and related tasks for better factory management.
    """,
    'author': 'eSya',
    'website': 'http://www.esya.com',
    'license': 'LGPL-3',
    'category': 'Manufacturing',
    'depends': [
        'base',
        'stock',  # Ensures inventory functionality
    ],
    'data': [
        'security/ir.model.access.csv',              # Access control list for models
        'views/factory_fix_views.xml',               # Views for the main Factory Fix model
        'views/calibration_template_views.xml',      # Views for Calibration Templates
        'views/gage_reference_view.xml',             # Gage Reference Views
        'views/user_defined_reference_views.xml',    # Views for User-Defined Reference
        'views/vendors_views.xml',                   # Vendor Management Views
        'views/study_views.xml',                     # Study Views for factory data
        'views/configure_views.xml',                 # Configuration Views
        'views/libraries_views.xml',                 # Libraries Views

    ],
    'demo': [
        'demo/factory_fix_demo.xml',                 # Optional demo data for testing
    ],
    'installable': True,
    'application': True,
    'auto_install': False,  # Module will not auto-install with dependencies

}
