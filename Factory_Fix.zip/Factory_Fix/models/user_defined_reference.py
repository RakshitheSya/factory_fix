from odoo import models, fields

class UserDefinedReference(models.Model):
    _name = 'user.defined.reference'
    _description = 'User Defined Reference'

    name = fields.Char(string="Reference Name", required=True)
    user_field1 = fields.Char(string="User Field1")
    user_field2 = fields.Char(string="User Field2")
    user_field3 = fields.Char(string="User Field3")
    user_field4 = fields.Char(string="User Field4")
    user_field5 = fields.Char(string="User Field5")
    user_field6 = fields.Char(string="User Field6")
    user_field7 = fields.Char(string="User Field7")
    user_field8 = fields.Char(string="User Field8")
    user_field9 = fields.Char(string="User Field9")
    user_field10 = fields.Char(string="User Field10")
