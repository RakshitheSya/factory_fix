from odoo import models, fields, api
from odoo.exceptions import ValidationError


class FactoryFix(models.Model):
    _name = 'factory.fix'
    _description = 'Factory Fix Master'

    # Core Fields
    name = fields.Char(string="Name", required=True)
    gage_id = fields.Char(string="Gage ID", required=True, help="Unique identifier for the gage.")
    gage_number = fields.Char(string="Gage Number", help="Numeric identifier for the gage.")
    gage_type = fields.Selection(
        [
            ('digital', 'Digital'),
            ('analog', 'Analog'),
        ],
        string="Gage Type",
        default='digital',
        help="Indicate whether the gage is digital or analog."
    )
    gage_description = fields.Text(string="Gage Description", help="Detailed description of the gage.")

    # Relationships
    belongs_to_group = fields.Many2one('res.groups', string="Belongs to Group", help="The group this gage belongs to.")
    home_location = fields.Many2one('stock.location', string="Home Location", help="The home location of the gage.")
    current_location = fields.Many2one('stock.location', string="Current Location", help="Current location of the gage.")
    owner = fields.Many2one('res.partner', string="Owner", help="Owner of the gage.")
    calibration_vendor = fields.Many2one('res.partner', string="Calibration Vendor", help="Vendor responsible for calibration.")

    # Additional Information
    calibration_source = fields.Char(string="Calibration Source", help="Source of calibration data.")
    current_status = fields.Selection(
        [
            ('in_use', 'In Use'),
            ('out_of_service', 'Out of Service'),
            ('calibration_due', 'Calibration Due'),
        ],
        string="Current Status",
        default='in_use',
        help="Indicates the current status of the gage."
    )
    gage_accuracy = fields.Float(string="Gage Accuracy", help="Accuracy of the gage.")

    # Specifications
    unit_of_measure = fields.Char(string="Unit of Measure", help="Unit of measure used by the gage.")
    gage_size = fields.Char(string="Gage Size", help="Size of the gage.")
    minimum = fields.Float(string="Minimum Value", help="Minimum measurable value.")
    maximum = fields.Float(string="Maximum Value", help="Maximum measurable value.")

    # Other Fields
    is_service = fields.Boolean(string="In Service", help="Indicates whether the gage is currently in service.")
    is_master = fields.Boolean(string="Is Master", help="Indicates whether this is a master gage.")
    image = fields.Binary(string="Image File", help="Upload an image of the gage.")
    comment = fields.Text(string="Comments For Use", help="Additional comments or usage notes.")

    # Related Fields for Due Dates
    due_date_ids = fields.One2many(
        'factory.fix.due.date',
        'gage_id',
        string="Due Dates",
        help="Due dates associated with the gage."
    )


    # Constraints and Validations
    @api.constrains('gage_id', 'gage_number')
    def _check_gage_identifiers(self):
        """Ensure that gage_id and gage_number are valid."""
        for record in self:
            if not record.gage_id:
                raise ValidationError("Gage ID must be provided.")
            if record.gage_number and not record.gage_number.isdigit():
                raise ValidationError("Gage Number must be a valid number if provided.")

    @api.constrains('minimum', 'maximum')
    def _check_min_max(self):
        """Ensure that Minimum value is less than or equal to Maximum."""
        for record in self:
            if record.minimum > record.maximum:
                raise ValidationError("Minimum value cannot exceed Maximum value.")

    # Button Actions
    def action_save_record(self):
        """Save the current record."""
        self.ensure_one()
        self.write({})
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': 'Success',
                'message': 'Record saved successfully!',
                'type': 'success',
                'sticky': False,
            },
        }

    def action_delete_record(self):
        """Delete the current record."""
        self.ensure_one()
        self.unlink()
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': 'Deleted',
                'message': 'Record deleted successfully!',
                'type': 'danger',
                'sticky': False,
            },
        }

    def action_update_record(self):
        """Update the current record."""
        self.ensure_one()
        self.write({})
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': 'Updated',
                'message': 'Record updated successfully!',
                'type': 'success',
                'sticky': False,
            },
        }

    def reset_status(self):
        """Reset the status of the gage to 'In Use'."""
        self.ensure_one()
        self.current_status = 'in_use'
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': 'Status Reset',
                'message': 'The status has been reset to "In Use".',
                'type': 'info',
                'sticky': False,
            },
        }

class FactoryFixDueDate(models.Model):
    _name = 'factory.fix.due.date'
    _description = 'Factory Fix Due Dates'

    gage_id = fields.Many2one('factory.fix', string="Gage", required=True, ondelete="cascade", help="Related gage.")
    due_date = fields.Date(string="Due Date", required=True, help="The due date for calibration or maintenance.")
    description = fields.Text(string="Description", help="Additional information about the due date.")

