from odoo import models, fields, api
from odoo.exceptions import ValidationError


class FactoryFix(models.Model):
    _name = 'factory.fix'
    _description = 'Factory Fix Master'

    # Core Fields
    name = fields.Char(string="Name", required=True)
    gage_id = fields.Char(string="Gage ID", required=True, help="Unique identifier for the gage.")
    gage_number = fields.Char(string="Gage Number", help="Numeric identifier for the gage.")
    gage_type = fields.Selection(
        [
            ('digital', 'Digital'),
            ('analog', 'Analog'),
        ],
        string="Gage Type",
        default='digital',
        help="Indicate whether the gage is digital or analog."
    )
    gage_description = fields.Text(string="Gage Description", help="Detailed description of the gage.")

    # Relationships
    belongs_to_group = fields.Many2one('res.groups', string="Belongs to Group", help="The group this gage belongs to.")
    home_location = fields.Many2one('stock.location', string="Home Location", help="The home location of the gage.")
    current_location = fields.Many2one('stock.location', string="Current Location", help="Current location of the gage.")
    owner = fields.Many2one('res.partner', string="Owner", help="Owner of the gage.")
    calibration_vendor = fields.Many2one('res.partner', string="Calibration Vendor", help="Vendor responsible for calibration.")

    # Additional Information
    calibration_source = fields.Char(string="Calibration Source", help="Source of calibration data.")
    current_status = fields.Selection(
        [
            ('in_use', 'In Use'),
            ('out_of_service', 'Out of Service'),
            ('calibration_due', 'Calibration Due'),
        ],
        string="Current Status",
        default='in_use',
        help="Indicates the current status of the gage."
    )
    gage_accuracy = fields.Float(string="Gage Accuracy", help="Accuracy of the gage.")

    # Specifications
    unit_of_measure = fields.Char(string="Unit of Measure", help="Unit of measure used by the gage.")
    gage_size = fields.Char(string="Gage Size", help="Size of the gage.")
    minimum = fields.Float(string="Minimum Value", help="Minimum measurable value.")
    maximum = fields.Float(string="Maximum Value", help="Maximum measurable value.")

    # Other Fields
    is_service = fields.Boolean(string="In Service", help="Indicates whether the gage is currently in service.")
    is_master = fields.Boolean(string="Is Master", help="Indicates whether this is a master gage.")
    image = fields.Binary(string="Image File", help="Upload an image of the gage.")
    comment = fields.Text(string="Comments For Use", help="Additional comments or usage notes.")

    # Due Dates Tab - Direct Fields
    time_period_calibration = fields.Char(string="Calibration time period", help="enter the time period of calibration.")
    last_calibrated_on = fields.Date(string="Last Calibrated On", help="Date of the last calibration.")
    uses_since_last_calib = fields.Integer(string="Uses Since Last Calibration", help="Number of uses since the last calibration.")
    calibration_due_on = fields.Date(string="Calibration Due On", help="Next calibration due date.")

    # Additional Reference Information Fields
    calibration_procedure = fields.Binary(string="Calibration Procedure File")
    rr_procedure = fields.Binary(string="RR Procedure File")
    maintenance_procedure = fields.Binary(string="Maintenance Procedure File")
    report_definition_file = fields.Binary(string="Select Report Definition File")
    reference_document2 = fields.Binary(string="Reference Document 2")
    reference_document3 = fields.Binary(string="Reference Document 3")

    master_1 = fields.Binary(string="Master 1 File")
    master_2 = fields.Binary(string="Master 2 File")
    master_3 = fields.Binary(string="Master 3 File")
    master_4 = fields.Binary(string="Master 4 File")
    master_5 = fields.Binary(string="Master 5 File")
    master_6 = fields.Binary(string="Master 6 File")

    # Calibration Template Fields
    sr_no = fields.Integer(string="Sr. No.")
    name = fields.Char(string="Name")
    is_attribute = fields.Boolean(string="Is Attribute")
    target_value = fields.Float(string="Target Value")
    units = fields.Char(string="Units")
    max_value = fields.Float(string="Max. Value")
    min_value = fields.Float(string="Min. Value")
    master = fields.Binary(string="Master")

    # Vendors Information Fields
    manufactured_by = fields.Char(string="Manufactured By")
    model_name = fields.Char(string="Model Name")
    serial_no = fields.Char(string="Serial No.")
    purchased_on = fields.Date(string="Purchased On")
    purchase_cost = fields.Float(string="Purchase Cost")
    purchased_from = fields.Many2one('res.partner', string="Purchased From")  # Reference to a partner (vendor)
    service_vendor = fields.Many2one('res.partner', string="Service Vendor")  # Reference to a partner (vendor)

    # User Defined Fields
    user_field1 = fields.Char(string="User Field 1")
    user_field2 = fields.Char(string="User Field 2")
    user_field3 = fields.Char(string="User Field 3")
    user_field4 = fields.Char(string="User Field 4")
    user_field5 = fields.Char(string="User Field 5")
    user_field6 = fields.Char(string="User Field 6")
    user_field7 = fields.Char(string="User Field 7")
    user_field8 = fields.Char(string="User Field 8")
    user_field9 = fields.Char(string="User Field 9")
    user_field10 = fields.Char(string="User Field 10")

    # Constraints and Validations
    @api.constrains('gage_id', 'gage_number')
    def _check_gage_identifiers(self):
        """Ensure that gage_id and gage_number are valid."""
        for record in self:
            if not record.gage_id:
                raise ValidationError("Gage ID must be provided.")
            if record.gage_number and not record.gage_number.isdigit():
                raise ValidationError("Gage Number must be a valid number if provided.")

    @api.constrains('minimum', 'maximum')
    def _check_min_max(self):
        """Ensure that Minimum value is less than or equal to Maximum."""
        for record in self:
            if record.minimum > record.maximum:
                raise ValidationError("Minimum value cannot exceed Maximum value.")


    # Save Button Action
    def action_save_record(self):
        """Logic for Save button."""
        # You can add custom logic here, for example:
        if not self.name:
            raise ValidationError("The name field is required.")
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': 'Record Saved',
                'message': 'The record has been successfully saved!',
                'type': 'success',
                'sticky': False,
            },
        }

    # Update Button Action
    def action_update_record(self):
        """Logic for Update button."""
        self.ensure_one()  # Ensure only one record is processed
        # Add custom update logic here
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': 'Record Updated',
                'message': 'The record has been successfully updated!',
                'type': 'success',
                'sticky': False,
            },
        }

    # Delete Button Action
    def action_delete_record(self):
        """Logic for Delete button."""
        self.ensure_one()
        self.unlink()
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': 'Record Deleted',
                'message': 'The record has been successfully deleted!',
                'type': 'danger',
                'sticky': False,
            },
        }

    def reset_status(self):
        """Reset the status of the gage to 'In Use'."""
        self.ensure_one()
        self.current_status = 'in_use'
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': 'Status Reset',
                'message': 'The status has been reset to "In Use".',
                'type': 'info',
                'sticky': False,
            },
        }