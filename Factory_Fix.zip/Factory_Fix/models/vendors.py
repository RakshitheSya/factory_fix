from odoo import models, fields, api
from odoo.exceptions import ValidationError

class GageVendor(models.Model):
    _name = 'gage.vendor'
    _description = 'Vendor Information'

    manufactured_by = fields.Many2one(
        'res.partner',
        string='Manufactured by',
        required=True,
        help='Select the partner who manufactured the item.'
    )
    purchased_on = fields.Date(string='Purchased on', help='Date when the item was purchased.')
    purchased_from = fields.Many2one(
        'res.partner',
        string='Purchased from',
        help='Select the partner from whom the item was purchased.'
    )
    model_name = fields.Char(string='Model Name', required=True, help='Enter the model name of the item.')
    purchase_cost = fields.Float(string='Purchase Cost', required=True, help='Enter the cost of purchase.')
    service_vendor = fields.Many2one(
        'res.partner',
        string='Service Vendor',
        help='Select the partner who provides service for the item.'
    )
    serial_no = fields.Char(string='Serial No', required=True, help='Enter the serial number of the item.')

    @api.constrains('serial_no')
    def _check_serial_no(self):
        for record in self:
            if not record.serial_no.isdigit():
                raise ValidationError("Serial No must contain only numbers.")
