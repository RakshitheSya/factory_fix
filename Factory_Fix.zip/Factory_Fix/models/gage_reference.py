# models/gage_reference.py
from odoo import models, fields

class GageReference(models.Model):
    _name = 'gage.reference'
    _description = 'Gage Reference'

    name = fields.Char(string="Reference Name")
    calibration_procedure = fields.Text(string="Calibration Procedure")
    rr_procedure = fields.Text(string="RR Procedure")
    maintenance_procedure = fields.Text(string="Maintenance Procedure")
    report_definition_file = fields.Binary(string="Select Report Definition File")
    reference_document2 = fields.Binary(string="Reference Document 2")
    reference_document3 = fields.Binary(string="Reference Document 3")
    master1 = fields.Char(string="Master 1")
    master2 = fields.Char(string="Master 2")
    master3 = fields.Char(string="Master 3")
    master4 = fields.Char(string="Master 4")
    master5 = fields.Char(string="Master 5")
    master6 = fields.Char(string="Master 6")
